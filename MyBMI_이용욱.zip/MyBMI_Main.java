
public class MyBMI_Main {

	public static void main(String[] args) {
		Member member = new Member();
		member.FirstMenu();
	}

}
