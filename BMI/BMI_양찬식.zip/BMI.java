package BMI;

import java.io.Serializable;
import java.util.Scanner;

public class BMI implements Serializable {
	private double length = 0;
	private double weight = 0;
	private double result = 0;
	private String you = "";
	
	public BMI input(BMI bmi) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Ű�� �Է��ϼ��� : ");
		length = sc.nextDouble();
		System.out.print("�����Ը� �Է��ϼ��� : ");
		weight = sc.nextDouble();
		result = weight/((length/100.0)*(length/100.0));
		if(result < 18.5) {
			you = "ü�� ����";
		} else if (18.5 <= result && result <= 22.9) {
			you= "����";
		} else if (23.0 <= result && result <= 24.9) {
			you = "��ü��";
		} else if(25.0 <=result) {
			you = "��";
		}
		return bmi;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getResult() {
		return result;
	}

	public void setResult(double result) {
		this.result = result;
	}

	public String getYou() {
		return you;
	}

	public void setYou(String you) {
		this.you = you;
	}

	@Override
	public String toString() {
		return "BMI [length=" + length + ", weight=" + weight + ", result=" + result + ", you=" + you + "]";
	}
}
