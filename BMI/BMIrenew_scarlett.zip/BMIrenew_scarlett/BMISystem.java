package BMIreset;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Properties;
import java.util.Scanner;
import java.util.Set;

public class BMISystem {
	static HashMap<String, Identification> idpwd;
	private Identification ip;
	private Set<String> set;
	static Scanner sc;
	static String inputid;
	static String inputpwd;
	File bmiusers;
	FileOutputStream fos;
	ObjectOutputStream oos;
	FileInputStream fis;
	ObjectInputStream ois;
	
	public BMISystem () {
		idpwd = new HashMap<String, Identification>();
		ip = new Identification ();
		set = idpwd.keySet();
	}
	public void sign_in () {
		
		loadUser ();
		
		System.out.println("사용할 Id를 입력해주세요.");
		String id = sc.nextLine();
			bmiusers = new File ("./BMI.txt");
			try {
				fos = new FileOutputStream (bmiusers);
				oos = new ObjectOutputStream(fos);
		        oos.writeObject(idpwd);
	}catch (Exception e) {
		e.getMessage();
	}finally {
		try {
		oos.close();
		fos.close();
	}catch (Exception e) {
		e.getMessage();
	}
	}
	}
	
	public void log_in () {
		
		loadUser ();
		System.out.println("id를 입력해주세요.");
		sc.nextLine();
			try {
			bmiusers = new File ("./BMI.txt");
			fis = new FileInputStream(bmiusers);
			ois = new ObjectInputStream (fis);
			idpwd = (HashMap)ois.readObject();
			if (! idpwd.containsKey(inputid)) {
				System.out.println("id를 다시 입력하세요.");
			}else {
				if (idpwd.get(inputid).getPwd().equals(inputpwd)){
					System.out.println("로그인 되었습니다.");			
					BMIManager bc = new BMIManager(); //데이터 정보 입력하는 곳으로 감.
					bc.bmiMenu();
				}else {
					System.out.println("비밀번호를 다시 확인해주세요.");
				}
			}
		}catch (Exception e ) {
			e.getMessage();
		}
		}
	
	public void loadUser () {
		bmiusers = new File ("./BMI.txt");
		if (bmiusers.exists()) {
			try {
				fis = new FileInputStream(bmiusers);
				ois = new ObjectInputStream(fis);
				idpwd = (HashMap) ois.readObject();
			}catch (Exception e) {
				e.getMessage();
			}finally {
				try {
					ois.close();
					fis.close();
				}catch (Exception e) {
					e.getMessage();
				}
			}
		}
	}
}

