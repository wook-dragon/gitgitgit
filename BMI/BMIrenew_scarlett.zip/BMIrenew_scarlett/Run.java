package BMIreset;

public class Run {
	public static void main(String[] args) {
		
        BMIManager bm = new BMIManager();
        bm.bmiMenu();
		

	}

}
