package BMIreset;

import java.io.Serializable;
import java.util.Scanner;

public class Identification implements Serializable{
	private String id;
	private String pwd;
	Scanner sc;
	
	public Identification () {
		
	}
	
	public Identification (String id, String pwd) {
		this.id = id;
		this.pwd =pwd;
	}
	
	public Identification inputIdentification () { //아이디, 패스워드입력. 
		BMI bmi = new BMI ();
		sc = new Scanner(System.in);
		System.out.println("id를 입력해주세요.");
		this.id =  sc.nextLine();
			System.out.println("사용자 모드입니다.");
			System.out.println("비밀번호를 입력해주세요.");
			this.pwd =sc.nextLine();
			bmi.input(bmi); //bmi 의 data input 모드로 들어간다. 	
		return null;
		}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	@Override
	public String toString() {
		return "Identification [id=" + id + ", pwd=" + pwd + "]";
	}

	


	
	
}
