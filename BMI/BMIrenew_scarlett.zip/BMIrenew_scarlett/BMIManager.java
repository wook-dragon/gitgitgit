package BMIreset;// 수연이가 다시 한 것.. 다른거 다 참고해서, 

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

public class BMIManager {
	static HashMap<Integer, BMI> map = new HashMap<Integer, BMI>();
	static int count = 1; 
	static Scanner sc = new Scanner (System.in);
	File file;
	FileOutputStream fos;
	ObjectOutputStream oos;
	FileInputStream fis;
	ObjectInputStream ois;

	public static void main(String[] args) {
		
		BMIManager bc = new BMIManager(); // 힙 메모리에 올리고, 
		bc.bmiMenu();
	}
	public void bmiMenu () {
		BMIManager bc = new BMIManager(); // 힙 메모리에 올리고, 
		do{
			
			System.out.println("+++++비만도를 측정해 보시겠습니까? ^^+++++ ");
			System.out.println("===============================");
			System.out.println("<1>추가하실 정보가 있으시면 1번을 눌러주세요.");
			System.out.println("<2>삭제하실 정보가 있으시면 2번을 눌러주세요.");
			System.out.println("<3>출력하실 정보가 있으시면 3번을 눌러주세요.");
			System.out.println("<4>저장하실 정보가 있으시면 4번을 눌러주세요.");
			System.out.println("<5> 로드하실 정보가 있으시면 5번을 눌러주세요.");
			System.out.println("<6> 프로그램을 종료하시려면 6번을 눌러주세요.");
			System.out.println("===============================");
			
			switch (sc.nextLine()) {
			case "1" : bc. add(); break;
			case "2" : bc.delete(); break;
			case "3" : bc.print(); break;
			case "4" : bc.save(); break;
			case "5" : bc.load(); break;
			case "6" : bc.exit(); break;
			case "7" : bmiMenu(); break;
			
			
			}
		}while(!sc.nextLine().equals("7"));
	}
	
	
	private void add ()  { // 1. 추가 하는 함수.
		BMI bmi = new BMI();
		file = new File("./BMI.txt");
		try {
			fis = new FileInputStream(file);
			ois  = new ObjectInputStream(fis);
			map.put(count, bmi.input(bmi));
			count++;
		}catch (Exception e) {
			e.getMessage();
		}finally {
			try {
			ois.close();
			fis.close();
			}catch (Exception e) {
				e.getMessage();
			}
		}
		
	}
	private void delete () { // 2. 삭제하는 함수.
		file = new File("./BMI.txt");
		try {
			fis = new FileInputStream(file);
			ois = new ObjectInputStream(fis);
			
		System.out.println("삭제할 숫자를 입력하세요.");
		int number = sc.nextInt();
		if (map.containsKey(number)) {//만약에 map 안에 키값이 number 입력한 값과 같은 경우 
			map.remove(number); //그 number 값을 지워라.
			System.out.println("입력한 숫자는 삭제되었습니다. ");	
		}else {
			System.out.println("입력한 숫자는 저장되어 있지 않은 숫자입니다. 해당 정보를 삭제할 수 없습니다.");
		}
		}catch (Exception e) {
			e.getMessage();
		}finally {
			try {
			ois.close();
			fis.close();
			}catch (Exception e) {
				e.getMessage();
			}
		}
		}

	private void print ()  {//3. 출력하는 함수 
		file = new File("./BMI.txt");
		try {
			
			fis = new FileInputStream (file);
			ois = new ObjectInputStream (fis);
		
		Set <Integer> set = map.keySet();
		System.out.println("번호 \t  키 \t 몸무게 \t 결과  \t 판정 \n");
		System.out.println();
		for(Integer number : set) {
			double height= map.get(number).getHeight();
			double weight = map.get(number).getWeight();
			double result = map.get(number).getResult();
			String one = map.get(number).getOne();
			
			System.out.printf("%s %.2f %.2f %.2f %s ", number,height,weight,result, one);
		}
		}catch (Exception e) {
			e.getMessage();
		}finally {
			try {
			ois.close();
			fis.close();
			}catch (Exception e) {
				e.getMessage();
			}
		}
		}
	
		private void save() {//4. 저장하는 함수. 
			file = new File ("./BMI.txt"); // 파일 생성. 
			try {
				fos = new FileOutputStream(file);
				oos = new ObjectOutputStream (fos);
				System.out.println("입력하신 정보가 잘 저장되었습니다^^ ");
				oos.writeObject(map);
				
			}catch (Exception e) {
				e.getMessage();
			}finally {
				try {
				oos.close();
				fos.close();
			}catch (Exception e) {
				e.getMessage();
			}
		}
		
	}
	private void load () { //5. 로드 하는 함수.
		file = new File ("./BMI.txt");
		try {
			fis = new FileInputStream(file);
			ois = new ObjectInputStream(fis);
			
			map = (HashMap) ois.readObject();
			
			Set<Integer> set = map.keySet();
			System.out.println("번호 키 몸무게 결과 판정");
			for (Integer number  : set) {
				double height = map.get(number).getHeight();
				double weight = map.get(number).getWeight();
				double result = map.get(number).getResult();
				String one = map.get(number).getOne();
				
				System.out.printf("%s %2.f %2.f %2.f %s", number, height, weight, result, one);
			}
			
		}catch (Exception e) {
			e.getMessage();
		}finally {
			try {
			ois.close();
			fis.close();
			}catch (Exception e) {
				e.getMessage();
			}
		}
	}
	private void exit ()  {// 6. 프로그램 종료 함수.
		System.out.println("프로그램을 종료하겠습니다.");
		System.exit(0);
		sc.close();
	}

}
	

