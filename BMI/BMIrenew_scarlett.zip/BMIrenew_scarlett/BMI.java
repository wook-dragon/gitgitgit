package BMIreset;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class BMI implements Serializable { // BMI 클래스, 
	private double height  =0; // 프라이빗 , 변수 선언;
	private double weight =0;
	private double result = 0;
	private String one =null;
	Scanner sc; 
	
	public BMI () {
		
	}
	
	public BMI (double height, double weight, double result) { // 초기화.,
		this.height = height; // 콘솔창에서 입력받는 값,
		this.weight = weight;
		this.result = result;
	}
	
	public BMI input (BMI bmi) { // input 입력함수 만들고, BMI 타입의 bmi 변수를 파라미터로 받고, 
		Identification id = new Identification();
		while (true) {
		sc = new Scanner(System.in);
		System.out.println("본인의 키를 입력해주세요.");
		this.height = sc.nextInt(); 
		System.out.println("본인의 몸무게를 입력해주세요.");
		this.weight = sc.nextInt();
		this.result = this.weight /((this.height/100.0)*(this.height/100.0));
		if(this.weight <=18.5) {
			System.out.println( this.one +"님 /t 체중 미달입니다. 살을 더 찌우세요. ");
		}else if ( 18.5 <=this.result && this.result <=22.9) {
			System.out.println(this.one + "님 /t 정상 체중입니다. 좋으시겠어요~^^");
		}else if (23.0 <=this.result && this.result <=24.9) {
			System.out.println(this.one + "님 /t 약간 과체중이시네요~^^ 간단한 운동 어떠세요?");
		}else if (25.0 <= this.result) {
			System.out.println(this.one + "님  /t 많이 과체중이시네요. 식이조절과 운동하는 건 어떠세요? ");
		}

		return bmi;
	}
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getResult() {
		return result;
	}

	public void setResult(double result) {
		this.result = result;
	}

	public String getOne() {
		return one;
	}

	public void setOne(String one) {
		this.one = one;
	}

	@Override
	public String toString() {
		return "BMI [height=" + height + ", weight=" + weight + ", result=" + result + ", one=" + one + "]";
	}
	
}
