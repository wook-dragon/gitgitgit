import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
public class User implements Serializable {
   private String cellNum; // �ڵ�����ȣ
   private String name; // �̸�
   private Date date; // �ð�
   private HashMap<Integer, String> borrowBook = null; // ���� å
   
   // �ð� ����
   public Date getDate() {
		return date;
	}
   //������
	public User() {
       super();
       date = new Date();
   }
	// �����ε� ������
   public User(String cellNum, String name) {
       super();
       this.cellNum = cellNum;
       this.name = name;
   }
   
   // getter name
   public String getName() {
       return name;
   }
   
   // setter name
   public void setName(String name) {
       this.name = name;
   }
   
   //  getter cellnum
   public String getCellNum() {
       return cellNum;
   }
   
   // setter cellnum
   public void setCellNum(String cellNum) {
       this.cellNum = cellNum;
   }
   
   // ����å�� �޴´�
   public HashMap<Integer, String> getBorrowBook() {
       if (borrowBook == null) {
           borrowBook = new HashMap<Integer, String>();
       }
       return borrowBook;
   }
   
   // toString
   @Override
  	public String toString() {
  		return "User [cellNum=" + cellNum + ", name=" + name + "]";
  	}
}
