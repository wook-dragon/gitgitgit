package gitgitgitjo;

public class Transaction { //�ŷ�����.
	String transactionDate;// �ŷ���¥.
	String transactionTime;//�ŷ��ð�.
	String kind;//�ŷ� ���� (�Ա�, ���)
	long amount; //�ŷ� �ݾ�, ��.
	long balance;// �ܰ�.

  public Transaction(String transactionDate, String transactionTime,String kind, long amount, long balance) {
   this.transactionDate = transactionDate;
   this.transactionTime = transactionTime;
   this.kind = kind;
   this.amount = amount;
   this.balance = balance;
}

@Override
public String toString() {
	return "Transaction [transactionDate=" + transactionDate + ", transactionTime=" + transactionTime + ", kind=" + kind
			+ ", amount=" + amount + ", balance=" + balance + "]";
}
  
}