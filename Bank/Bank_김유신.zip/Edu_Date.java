package gitgitgitjo;

import java.util.Calendar;

public class Edu_Date {
    public static String DateString(Calendar date) {
        return date.get(Calendar.YEAR) + "��"
                +(date.get(Calendar.MO   
        String hour = (date.get(Calendar.HOUR_OF_DAY)>9)?Integer.toString(date.get(Calendar.HOUR_OF_DAY)):"0"+Integer.toString(date.get(Calendar.HOUR_OF_DAY));
        String minute = (date.get(Calendar.MINUTE)>9)?Integer.toString(date.get(Calendar.MINUTE)):"0"+Integer.toString(date.get(Calendar.MINUTE));
        String second = (date.get(Calendar.SECOND)>9)?Integer.toString(date.get(Calendar.SECOND)):"0"+Integer.toString(date.get(Calendar.SECOND));
        return hour + ":" + minute +":"+second;
    }
}
