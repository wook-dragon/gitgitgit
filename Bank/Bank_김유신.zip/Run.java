package gitgitgitjo;

public class Run {

	public static void main(String[] args) {
		Bank bk = new Bank();
		bk.addAccount("1234", "scarlett");
	}

}
