import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
	
		Bank bk = new Bank();
		//계좌 생성, 이름 넣기.
		bk.addAccount("1234","scarlett");
	    bk.addAccount("5678", "bread");
	    bk.addAccount("7890", "jones");
	    
	    //입금하기.
	    bk.getAccounts().get(0).deposit(1000);
	    System.out.println(bk.getAccounts().get(0).toString());
	    System.out.println();
	    bk.getAccounts().get(1).deposit(1000);
	    System.out.println(bk.getAccounts().get(1).toString());
	    System.out.println();
	    bk.getAccounts().get(2).deposit(2000);
	    bk.getAccounts().get(2).deposit(3000);
	    System.out.println(bk.getAccounts().get(2).toString());
	    System.out.println();
	    
	    //출금하기.
        bk.getAccounts().get(2).withdraw(1000);
        System.out.println(bk.getAccounts().get(2).toString());
        System.out.println();
        bk.getAccounts().get(2).getBalance();
        System.out.println(bk.getAccounts().get(2).toString());
        
        //잔고 없는 상태에서 출금하기.
        bk.getAccounts().get(2).withdraw(3000);
        System.out.println(bk.getAccounts().get(2).toString());
        
        //계좌 찾기.
        bk.findAccounts("dd");
     
	}

}
