import java.util.ArrayList;
import java.util.Scanner;

public class Bank {
	ArrayList<Account> accounts;
	int totalAccount;
    Scanner sc; // 밑에서 계좌 번호와 이름 받기.
	
	public Bank() {
		accounts = new ArrayList<Account>();
	}
	public void addAccount (String accountNo, String name) {
		accounts.add(new Account(accountNo,name)); //Account 클래스를 new를 통해 불러와 계좌번호와  이름을 추가하면 계좌들에 들어감.
	    totalAccount++; //총 계좌 를 후치로 ++ 하겠다.
	}
	public Account getAccount (String accountNo) { // 계좌 보기.
		Account account = null; //계좌 클래스에서 어카운트가 null; 인 걸 선언;
		for (Account value : accounts) // for 문을 통해 계좌 클래스 에서value값이 계좌 목록들을 타고 다닐 때.
			if (value.getAccountNo().equals(accountNo)) { //만약에 계좌 클래스에서value값이 .console창에서 읽은 계좌번호와 원래 있던 계좌번호와 equals같으면,
				System.out.println("고객님, 계좌번호가 맞습니다.");
			}else {
				System.out.println("고객님 계좌번호가 아닙니다.");
			}
		return account;
	}
	public ArrayList<Account> findAccounts (String name) { //계좌 찾기 , 이름으로.
	    ArrayList<Account> account = new ArrayList();
		for (int i = 0; i <accounts.size(); i++) {
	    	if(accounts.get(i).getName().equals(name)){
	    		account.add(accounts.get(i));
	    		System.out.println("소유주 명이 맞습니다.");
	    	}else {	
	    		
	    		System.out.println("소유주 명이 아닙니다.");
	    		break;
	    	}
	    }
		return account;
	}
	public ArrayList<Account> getAccounts() { //여러 계좌 번호 보기.
		return accounts;
	}
	public int TotalAccount() {
		return totalAccount;
	}

}
