import java.util.Calendar;

public class Date {
	public static String DateString (Calendar date) {
		return date.get(Calendar.YEAR) +"년" 
				+(date.get(Calendar.MONTH+1))+ "월"
				+date.get(Calendar.DATE) +"일";
	}
	
	public static String DateString (Calendar date, String s) {
		return date.get(Calendar.YEAR) +s
			      +(date.get(Calendar.MONTH)+1) +s
                  +date.get(Calendar.DATE);
	}
	public static String monthFormat_DateString (Calendar date){
		String year = Integer.toString(date.get(Calendar.YEAR));
		String month = (date.get(Calendar.MONTH)>8) ? Integer.toString(date.get(Calendar.MONTH)+1) : "0" +Integer.toString(date.get(Calendar.MONTH));
		String day = (date.get(Calendar.DATE)>9)?Integer.toString(date.get(Calendar.DATE)):"0"+Integer.toString(date.get(Calendar.DATE));
		return year + month +day;
	}
		 public static String getTime(Calendar date) {
		        String hour = (date.get(Calendar.HOUR_OF_DAY)>9)?Integer.toString(date.get(Calendar.HOUR_OF_DAY)):"0"+Integer.toString(date.get(Calendar.HOUR_OF_DAY));
		        String minute = (date.get(Calendar.MINUTE)>9)?Integer.toString(date.get(Calendar.MINUTE)):"0"+Integer.toString(date.get(Calendar.MINUTE));
		        String second = (date.get(Calendar.SECOND)>9)?Integer.toString(date.get(Calendar.SECOND)):"0"+Integer.toString(date.get(Calendar.SECOND));
		        return hour + ":" + minute +":"+second;
	}
}
