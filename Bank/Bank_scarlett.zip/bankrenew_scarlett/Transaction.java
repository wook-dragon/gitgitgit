
public class Transaction { //멤버 필드 안에 객체 선언;
	String transactionDate;
	String transactioinTime;
	String kind;
	long amount;
	long balance;
	
	public Transaction (String kind, long amount, long balance) { // 쓰고 싶은 객체들 파라미터로 받고 초기화. //private 로 쓰면 계좌에서 거래목록을 new를 못하니까 .
		this.kind = kind;
		this.amount = amount;
		this.balance = balance;
	}

	@Override
	public String toString() { // new Transaction한 곳에서 오버라이드로 재정의 하기 위해 씀.
		return "거래내역 " + kind + ", 금액.=" + amount + ",잔액.=" + balance + "]";
	}
	
}
