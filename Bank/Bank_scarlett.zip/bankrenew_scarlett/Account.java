import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Calendar;

public class Account { //멤버필드 안에 객체 선언;
	String accountNo;
	String name;
	long balance;
	ArrayList<Transaction> transactions; //배열 대신 동적배열로 어레이리스트에 받음.
	
	public Account () {
		
	}
	public Account (String accountNo, String name) { // console창에서 받은 값들이 적용되어야 할 경우에 파라미터로 받고,
		this.accountNo = accountNo;
		this.name = name;
		transactions = new ArrayList<Transaction>(); 
	}
	public void deposit (long amount) { //입금.
		Calendar date = Calendar.getInstance(); //날짜나오기.
	    String dayt = Date.monthFormat_DateString(date);
	    String timet = Date.getTime(date);
	   this.balance = this.balance+amount  ; // 잔액 + 입금 금액 = 전체 금액.
	   transactions.add(new Transaction (dayt +"\t"+timet +"분"+"\t"+"입금되었습니다",amount, balance)); 
	   
	}
	public void withdraw (long amount) {
		Calendar date = Calendar.getInstance(); //날짜나오기.
		String dayt = Date.monthFormat_DateString(date);
	    String timet = Date.getTime(date);
	   this.balance =this.balance - amount; //잔액 -출금 금액 = 남은 금액 .
	   transactions.add(new Transaction (dayt +"\t"+timet +"분"+"\t"+"출금되었습니다.",amount,balance));
	   if (balance <amount) {
		   System.out.println("잔고가 부족합니다.");
	   }else {
		   this.balance =this.balance - amount; // 잔고에서 출금하면, 
		   transactions.add(new Transaction (dayt +"\t"+timet +"분"+"\t"+"출금되었습니다.",amount,balance)); //거래내역 불러와서 출금되었습니다 라고문구 출력.
	   }
	}
	public long getBalance () {
		return this.balance; //잔액 보여줌.
	}
	public String getAccountNo () {
		return accountNo;
	}
	public String getName () {
		return name;
	}
	public ArrayList<Transaction> transactions() {
		return transactions;
	}
	@Override
	public String toString() {
		return "계좌" + getAccountNo() + "예금주" +getName() + "잔액"  +getBalance() +"\n" +"전체 거래내역" +transactions;
	
	}
   
}
