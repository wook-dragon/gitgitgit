import java.util.ArrayList;

public class Bank {
	private ArrayList<Account> accounts;
	private int totalAccount;
	Account acc;
	
	public Bank() {
		
		accounts = new ArrayList<Account>();
		
	}
	
	public void addAccount(String accountNo, String name) {
		acc = new Account(accountNo, name);
		totalAccount++;
		accounts.add(acc);
	}
	
	public Account getAccount(String accountNo) {
		Account result = new Account();
		for(int i=0; i<accounts.size(); i++) {
			if(accounts.get(i).getAccountNo().equals(accountNo)) {
				result = accounts.get(i);
			}else {
				System.out.println("�Է��� ���¹�ȣ�� ���� ���´� �����ϴ�.");
			}
		}
		return result;
	}
	
	public ArrayList<Account> findAccounts(String name) {
		ArrayList<Account> resultList = new ArrayList<Account>();
		for(int i=0; i<accounts.size(); i++) {
			if(accounts.get(i).getAccountNo().equals(name)) {
				resultList.add(accounts.get(i));
			}else {
				System.out.println("�Է��� ���¹�ȣ�� ���� ���´� �����ϴ�.");
			}
		}
		return resultList;
				
		
	}
	
	
	
	
	
	
	public ArrayList<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(ArrayList<Account> accounts) {
		this.accounts = accounts;
	}
	public int getTotalAccount() {
		return totalAccount;
	}
	public void setTotalAccount(int totalAccount) {
		this.totalAccount = totalAccount;
	}
	
	
	
	
	
	
	

}
