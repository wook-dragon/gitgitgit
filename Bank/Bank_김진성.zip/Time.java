import java.util.Calendar;

public class Time {
	
	public static String DateString(Calendar date) {
		return date.get(Calendar.YEAR) + "��"
				+ date.get(Calendar.MONTH) + "��"
				+ date.get(Calendar.DATE) + "��";	
	}
	/*
	public static String DateString(Calendar date, String opr) {
		return date.get(Calendar.YEAR) + opr
				+ (date.get(Calendar.MONTH)+1) + opr
				+date.get(Calendar.DATE);
	}
	
	public static String monthFormat_DateString(Calendar date) {
		return null;
	}
	*/
	public static String TimeString(Calendar date) {
		return date.get(Calendar.HOUR) + "��"
				+ date.get(Calendar.MINUTE) + "��"
				+ date.get(Calendar.SECOND) + "��";
	}

}
