import java.util.Calendar;

public class Excute {

	public static void main(String[] args) {
		
		String coment = "���̵�� �̸��Ϸ� �ʾ��ּ��� , ���̵�:";
		String[] arr = coment.split(",");
		for(String s : arr) {
			System.out.println(s);
		}
		System.out.println();
		System.out.println(coment);
		
		/*
		Bank b = new Bank();
		
		b.addAccount("10005-123", "���ο�");
		
		
		
		System.out.println(b.getAccount("10005-123"));
		
		b.getAccount("10005-123").deposit(1000000);
		
		
		System.out.println(b.getAccount("10005-123"));
		
		b.getAccount("10005-123").withraw(2546);
		
		System.out.println(b.getAccount("10005-123"));
		
		
		for(int i=0; i<b.getAccount("10005-123").getTranList().size(); i++) {
			System.out.println(b.getAccount("10005-123").getTranList().get(i));
		}
		*/
	
		
		

	}

}
