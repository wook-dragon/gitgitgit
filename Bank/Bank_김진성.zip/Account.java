import java.util.ArrayList;

public class Account {
	
	private String accountNo;
	private String name;
	private long balance;
	private ArrayList<Transaction> tranList;
	Transaction tran;
	
	Account() {
		
	}
	
	public Account(String accountNo, String name) {
		//super();
		this.accountNo = accountNo;
		this.name = name;
		tranList = new ArrayList<Transaction>();
	}
	
	public void deposit(long amount) {
		balance += amount;
		tran = new Transaction("�Ա�", amount);
		tran.setBalance(balance);
		tranList.add(tran);
		
		
	}
	
	public void withraw(long amount) {
		balance -= amount;
		tran = new Transaction("���", amount);
		tran.setBalance(balance);
		tranList.add(tran);
	}
	
	
	
	
	
	
	
	
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", name=" + name + ", balance=" + balance + "]";
	}

	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getBalance() {
		return balance;
	}
	
	public ArrayList<Transaction> getTranList() {
		return tranList;
	}
	//public void setTranList(ArrayList<Transaction> tranList) {
	//	this.tranList = tranList;
	//}
	
	

}
