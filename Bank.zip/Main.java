
public class Main {

	public static void main(String[] args) {
		Run r = new Run();
		r.run();
	}

}
