package BankBank;

public class Transaction {
	private String transactionDate; // �ŷ���
	private String transactionTime; // �ŷ��ð�
	private String kind; // ����( �Ա� �Ǵ� ���)
	private long amount; // �ŷ��ݾ�
	private long balance; // �ܰ�
	
	public Transaction(String transactionDate, String transactionTime, String kind, long amount, long balance) {
		super();
		this.transactionDate = transactionDate;
		this.transactionTime = transactionTime;
		this.kind = kind;
		this.amount = amount;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Transaction [transactionDate=" + transactionDate + ", transactionTime=" + transactionTime + ", kind="
				+ kind + ", amount=" + amount + ", balance=" + balance + "]";
	}
	
	
	
	
	
}
