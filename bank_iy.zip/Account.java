package BankBank;

import java.util.ArrayList;
import java.util.Calendar;

public class Account {
	private String accountNo; // ���¹�ȣ
	private String name; // �����ڸ�
	private long balance; //�ܰ�
	ArrayList<Transaction> transactions;  //�ŷ����� (0���̻�)
	
	
	
	public String getAccountNo() {
		return accountNo;
	}

	public String getName() {
		return name;
	}

	public Account(String account, String name) {
		super();
		this.accountNo = account;
		this.name = name;
		this.balance = balance;
		transactions = new ArrayList<Transaction>();
	}

	public void deposit(long amount) { // �Ա��Ѵ�
		Calendar date = Calendar.getInstance();
        String dayOfTransaction = Edu_Date.monthFormat_DateString(date);
        String transactionTime = Edu_Date.getTime(date);
        this.balance += amount;
        transactions.add(new Transaction(dayOfTransaction, transactionTime, "�Ա�", amount, balance));
	}
	
	public void withdraw(long amount) { // ����Ѵ�
		  String transactionDate = Edu_Date.monthFormat_DateString(Calendar.getInstance());
	      String transactionTime = Edu_Date.getTime(Calendar.getInstance());
		this.balance -= amount;
		 transactions.add(new Transaction(transactionDate, transactionTime, "���", amount, balance));
	}
	
	public long getBalance() { //�ܰ��� Ȯ���Ѵ�
		
		
		return balance;
		
	}
	
	public ArrayList<Transaction> getTransactions() { // �ŷ������� ����
		
		return transactions;

	}
	
	
	
}
